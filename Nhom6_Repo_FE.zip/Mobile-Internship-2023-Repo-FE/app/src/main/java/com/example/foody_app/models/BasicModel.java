package com.example.foody_app.models;

public class BasicModel {
}
