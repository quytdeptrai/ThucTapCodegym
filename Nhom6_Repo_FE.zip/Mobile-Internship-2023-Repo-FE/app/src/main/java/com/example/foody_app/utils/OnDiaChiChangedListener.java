package com.example.foody_app.utils;

public interface OnDiaChiChangedListener {
    void onDiaChiChanged(String newDiaChi, String newName, String newPhoneNumber);
}
