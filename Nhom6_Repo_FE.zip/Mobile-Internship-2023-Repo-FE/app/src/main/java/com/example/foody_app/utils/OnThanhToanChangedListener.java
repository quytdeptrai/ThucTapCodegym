package com.example.foody_app.utils;

public interface OnThanhToanChangedListener {
    void onPaymentMethodChanged(String newPaymentMethod);
}
