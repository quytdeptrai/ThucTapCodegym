package com.example.foody_app.adapter;

public class BasicAdapter {
}
