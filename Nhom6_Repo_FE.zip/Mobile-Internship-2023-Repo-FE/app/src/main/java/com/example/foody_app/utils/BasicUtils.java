package com.example.foody_app.utils;

public class BasicUtils {
}
