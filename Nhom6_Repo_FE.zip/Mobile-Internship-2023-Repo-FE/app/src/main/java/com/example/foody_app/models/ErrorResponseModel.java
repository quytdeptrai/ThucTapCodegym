package com.example.foody_app.models;

public class ErrorResponseModel {
    private String message;

    public String getMessage() {
        return message;
    }
}
