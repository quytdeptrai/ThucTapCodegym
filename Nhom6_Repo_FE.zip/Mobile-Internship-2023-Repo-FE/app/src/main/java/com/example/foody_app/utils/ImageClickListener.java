package com.example.foody_app.utils;

import android.view.View;

public interface ImageClickListener {
    void onImageClick(View view, int pos, int giatri);
}
